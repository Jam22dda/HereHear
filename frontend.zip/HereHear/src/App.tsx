import './App.css';

export default function App() {
    return (
        <div id='display'>
            <div className='container'>
                <h1>App</h1>
            </div>
        </div>
    );
}
