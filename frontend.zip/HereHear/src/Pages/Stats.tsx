export default function Stats() {
    return (
        <div id='display'>
            <div className='container'>
                <h1>Stats</h1>
            </div>
        </div>
    );
}
