export default function MyRegist() {
    return (
        <div id='display'>
            <div className='container'>
                <h1>MyRegist</h1>
            </div>
        </div>
    );
}
