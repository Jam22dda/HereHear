export default function SelectMusic() {
    return (
        <div id='display'>
            <div className='container'>
                <h1>SelectMusic</h1>
            </div>
        </div>
    );
}
