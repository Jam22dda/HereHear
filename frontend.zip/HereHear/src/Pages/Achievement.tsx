export default function Achievement() {
    return (
        <div id='display'>
            <div className='container'>
                <h1>Achievement</h1>
            </div>
        </div>
    );
}
