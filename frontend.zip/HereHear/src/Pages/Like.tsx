export default function Like() {
    return (
        <div id='display'>
            <div className='container'>
                <h1>Like</h1>
            </div>
        </div>
    );
}
