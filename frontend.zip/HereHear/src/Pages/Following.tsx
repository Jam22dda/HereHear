export default function Following() {
    return (
        <div id='display'>
            <div className='container'>
                <h1>Follow</h1>
            </div>
        </div>
    );
}
