export default function RegistMusic() {
    return (
        <div id='display'>
            <div className='container'>
                <h1>RegistMusic</h1>
            </div>
        </div>
    );
}
