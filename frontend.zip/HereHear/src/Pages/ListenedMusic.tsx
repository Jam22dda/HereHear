export default function ListenedMusic() {
    return (
        <div id='display'>
            <div className='container'>
                <h1>ListenedMusic</h1>
            </div>
        </div>
    );
}
